NovaBiz V3 neutral SVG/icon asset folder.
